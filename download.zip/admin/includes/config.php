<?php
/**
 * Database Configuration
 * Car Rental System
 */

define('DB_HOST', 'sql207.infinityfree.com');
define('DB_NAME', 'if0_41009918_cariton');
define('DB_USER', 'if0_41009918');
define('DB_PASS', 'hhwJ7f00pSoVi2');

// Currency Configuration
define('DEFAULT_CURRENCY', 'PHP');
define('CURRENCY_SYMBOL', '₱');
define('EXCHANGE_RATES', [
    'PHP' => 1.00,
    'USD' => 0.018,
    'EUR' => 0.016,
    'GBP' => 0.014,
    'JPY' => 2.65
]);

// Initialize session and database
session_start();

// Database connection
function getDBConnection() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}

// Currency helper functions
function formatCurrency($amount, $currency = DEFAULT_CURRENCY) {
    global $CURRENCY_SYMBOLS;
    $symbol = isset($CURRENCY_SYMBOLS[$currency]) ? $CURRENCY_SYMBOLS[$currency] : $currency . ' ';
    return $symbol . number_format($amount, 2);
}

function convertCurrency($amount, $from = 'USD', $to = DEFAULT_CURRENCY) {
    if ($from === $to) return $amount;
    
    $inBase = $amount * (EXCHANGE_RATES[$from] ?? 1);
    return $inBase / (EXCHANGE_RATES[$to] ?? 1);
}

$CURRENCY_SYMBOLS = [
    'PHP' => '₱',
    'USD' => '$',
    'EUR' => '€',
    'GBP' => '£',
    'JPY' => '¥'
];

// Helper functions
function isLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function generateReference($prefix = 'REF') {
    return $prefix . '-' . strtoupper(bin2hex(random_bytes(4)));
}
